class scene extends Phaser.Scene {
    constructor(){
        super({key:"scene"});
    }


    preload(){
        this.load.image('Player', 'assets/player.png');

        this.load.image('floor', 'assets/Platform.png');

        this.load.audio('Sound', 'assets/death.mp3');
    }

    create(){

        platforms = this.physics.add.staticGroup();

        platforms.create(256, 256, 'floor');

        player = this.physics.add.sprite(256, 200, 'Player');

        player.setBounce(0.1);
        player.setCollideWorldBounds(true);

        this.physics.add.collider(player, platforms);

        this.soundFX = this.sound.add('Sound', { loop:true });


        this.key_A = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.A);
        this.key_D = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.D);

        this.soundFX.play();
    }
    update(delta){
        if(this.key_A.isDown){
            player.setVelocityX(-80);
        }
        if(this.key_D.isDown){
            player.setVelocityX(80);
        }

    }
}